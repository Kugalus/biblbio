def chuj():
    print("ppenis")