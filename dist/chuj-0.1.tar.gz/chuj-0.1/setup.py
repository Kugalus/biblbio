from setuptools import setup

setup(
    name="chuj",
    version='0.1',
    description='to jest kurwa biblioteka',
    url='',
    author='josif stalin',
    author_email='josifstalin@microsoft.com',
    license='unlicense',
    packages=['biblbio'],
    zip_safe=False
)